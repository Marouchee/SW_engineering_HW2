#pragma once
#include <string>

using namespace std;

class CurrentUser {
public:
	/** ���� �� ���� �ʱ�ȭ */
	explicit CurrentUser();
	void login(const string& id);
	void logout();
	const string& getUserId() const;

private:
	string user_id;
	string status;
};