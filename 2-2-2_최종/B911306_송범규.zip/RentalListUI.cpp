#include <fstream>
#include <algorithm>
#include "RentalListUI.h"

RentalListUI::RentalListUI(RentalListController* rc, ostream* os)
    : controller(rc), out(os) {
}
void RentalListUI::enterShowList() {
    auto list = controller->requestRentalList();
    // ������ ID ������ ����
    sort(list.begin(), list.end(),
        [](auto& a, auto& b) {
            return a.getBike().getId() < b.getBike().getId();
        });
    *out << "5.1. ������ �뿩 ����Ʈ\n";
    for (auto& r : list) {
        *out << "> " << r.getBike().getId() << " "
            << r.getBike().getModel() << "\n";
    }
    *out << "\n";
}